/**
 *  Document   : summernote-data.js
 *  Author     : redstar
 *  Description: script for summernote
 *
 **/
"use strict";
$('#summernote').summernote({
        placeholder: '',
        tabsize: 2,
        height: 200
      });

$('#formsummernote').summernote({
    placeholder: '',
    tabsize: 2,
    height: 350
  });